from base.config import Config

EMBEDDING = "embedding"
