class Config:
    def __init__(self):
        self.openapi_base = "https://openkey.cloud"
        self.openapi_key = "sk-yHHCkvV5fuS83ZDPiSTUsvsS6sUUKXXJwOuzScXz7tCd3aNH"
