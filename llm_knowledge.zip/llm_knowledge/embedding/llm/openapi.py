from embedding.llm.base import BaseLLM
from base import Config
import openai
import requests

class Openapi(BaseLLM):
    def __init__(self, config: 'Config'):
        self.__config = config
        self.__base_url = config.openapi_base
        self.__api_key = config.openapi_key
        print(self.__base_url, self.__api_key)
        self.__context = []

    def embedding(self, text: str) -> dict[dict]:
        data = {
            "model": "text-embedding-ada-002",
            "input": text
        }
        headers = {
            "Content-Type": "application/json",
            "Authorization": f"Bearer {self.__api_key}"
        }
        print(f"{self.__base_url}/v1/engines/davinci-codex/completions")
        response = requests.post(f"{self.__base_url}/v1/engines/davinci-codex/completions", headers=headers, json=data)
        embedding = response.json()['data'][0]['embedding']
        return embedding

    def ask(self, query: str, context: str) -> str:
        messages = [
            {"role": "system", "content": f'你是一个乐于助人的作者，你需要从下文中提取有用的内容来解答用户提出的问题，不能回答不在下文提到的内容，回答请以我的视角回答：\n\n{context}'}
        ]
        self.__context.append({"role": "user", "content": query})
        messages.extend(self.__context)
        data = {
            "model": "gpt-3.5-turbo-16k",
            "messages": messages
        }
        headers = {
            "Content-Type": "application/json",
            "Authorization": f"Bearer {self.__api_key}"
        }
        response = requests.post(f"{self.__base_url}/v1/chat/completions", headers=headers, json=data)
        answer = response.json()['choices'][0]['message']['content']
        print("使用的tokens：", response.json()['usage']['total_tokens'])
        self.__context.append({"role": "assistant", "content": answer})
        return answer

    def clear(self):
        self.__context = []
